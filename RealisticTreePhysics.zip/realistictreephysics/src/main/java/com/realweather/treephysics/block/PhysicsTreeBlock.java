package com.realweather.treephysics.block;

import com.realweather.treephysics.blockentity.PhysicsTreeBlockEntity;
import com.realweather.treephysics.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * One placed block = the root of a procedurally generated tree whose
 * whole shape (trunk + every branch) is drawn and animated entirely by
 * {@link com.realweather.treephysics.client.render.PhysicsTreeRenderer}.
 * The vanilla block model itself is invisible on purpose.
 */
public class PhysicsTreeBlock extends BaseEntityBlock {

    public PhysicsTreeBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PhysicsTreeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        // Physics only needs to run where the tree is actually seen, so it's client-only.
        return level.isClientSide
                ? createTickerHelper(type, ModBlockEntities.PHYSICS_TREE.get(), PhysicsTreeBlockEntity::clientTick)
                : null;
    }

    @Override
    public AABB getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        // A real tree isn't a 1x1x1 cube - don't let it occlude neighbours.
        return AABB.ofSize(Vec3.atCenterOf(pos), 0, 0, 0);
    }
}

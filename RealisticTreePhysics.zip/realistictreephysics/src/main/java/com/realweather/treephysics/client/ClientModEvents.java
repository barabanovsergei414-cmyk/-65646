package com.realweather.treephysics.client;

import com.realweather.treephysics.TreePhysicsMod;
import com.realweather.treephysics.client.render.PhysicsTreeRenderer;
import com.realweather.treephysics.registry.ModBlockEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterRenderers;

@EventBusSubscriber(modid = TreePhysicsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerRenderers(RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.PHYSICS_TREE.get(), PhysicsTreeRenderer::new);
    }
}
